package com.silverframes.deviceagent

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * The brain: sends the goal + current screen to Claude, executes the tool
 * call it returns, sends the new screen back, repeats until done.
 */
class Agent(
    private val ctx: Context,
    private val apiKey: String,
    private val log: (String) -> Unit,
    private val confirm: suspend (String) -> Boolean   // asks YOU before risky taps
) {
    private val http = OkHttpClient.Builder().readTimeout(90, TimeUnit.SECONDS).build()
    private val risky = Regex("send|pay|buy|purchase|delete|remove|transfer|confirm|order|post|submit|uninstall",
        RegexOption.IGNORE_CASE)

    @Volatile var stopped = false
    @Volatile var askBeforeRisky = false   // default: fully autonomous

    private fun tool(name: String, desc: String, props: JSONObject = JSONObject(), req: List<String> = emptyList()) =
        JSONObject().put("name", name).put("description", desc).put("input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(req)))

    private fun p(type: String, desc: String) = JSONObject().put("type", type).put("description", desc)

    private val tools = JSONArray().apply {
        put(tool("tap", "Tap the screen. Use x,y from the screen JSON. label = what you are tapping.",
            JSONObject().put("x", p("integer", "x")).put("y", p("integer", "y")).put("label", p("string", "text of the target")),
            listOf("x", "y", "label")))
        put(tool("type_text", "Type text into the focused input field (tap the field first).",
            JSONObject().put("text", p("string", "text")), listOf("text")))
        put(tool("swipe", "Swipe/scroll: up, down, left or right.",
            JSONObject().put("direction", p("string", "up|down|left|right")), listOf("direction")))
        put(tool("open_app", "Open an installed app by its name.",
            JSONObject().put("name", p("string", "app name, e.g. Chrome")), listOf("name")))
        put(tool("press", "Press a system button: back, home, recents, notifications.",
            JSONObject().put("button", p("string", "back|home|recents|notifications")), listOf("button")))
        put(tool("finish", "Call when the task is complete or impossible.",
            JSONObject().put("summary", p("string", "what happened")), listOf("summary")))
    }

    private val system = "You are an agent operating an Android phone for its owner. Each turn you see the " +
        "visible screen as JSON (text, x, y). Take ONE action per turn using the tools. Be careful and " +
        "minimal. Never enter passwords or payment details. If unsure, call finish and explain."

    suspend fun run(goal: String) = withContext(Dispatchers.IO) {
        val svc = AgentService.instance
        if (svc == null) { log("Turn on the Device Agent accessibility service first."); return@withContext }
        val msgs = JSONArray().put(userMsg("Goal: $goal\n\nScreen:\n${svc.screenToJson()}"))

        repeat(30) {
            if (stopped) { log("Stopped."); return@withContext }
            val resp = call(msgs)
            val content = resp.optJSONArray("content")
            if (content == null) { log("API error: $resp"); return@withContext }
            msgs.put(JSONObject().put("role", "assistant").put("content", content))

            val results = JSONArray(); var done = false
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.getString("type")) {
                    "text" -> log(b.getString("text"))
                    "tool_use" -> {
                        val name = b.getString("name")
                        val out = exec(name, b.getJSONObject("input"))
                        if (name == "finish") done = true
                        delay(1200)
                        results.put(JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id"))
                            .put("content", "$out\n\nScreen:\n${svc.screenToJson()}"))
                    }
                }
            }
            if (done || results.length() == 0) return@withContext
            msgs.put(JSONObject().put("role", "user").put("content", results))
        }
        log("Step limit reached.")
    }

    private fun userMsg(t: String) = JSONObject().put("role", "user").put("content", t)

    private fun call(msgs: JSONArray): JSONObject {
        val body = JSONObject()
            .put("model", "claude-sonnet-4-6").put("max_tokens", 1024)
            .put("system", system).put("tools", tools).put("messages", msgs)
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey).header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        http.newCall(req).execute().use { return JSONObject(it.body!!.string()) }
    }

    private suspend fun exec(name: String, a: JSONObject): String {
        val s = AgentService.instance ?: return "service off"
        return when (name) {
            "tap" -> {
                val label = a.optString("label")
                if (askBeforeRisky && risky.containsMatchIn(label) && !confirm("Agent wants to tap \"$label\". Allow?")) "User denied this action."
                else { s.tap(a.getInt("x"), a.getInt("y")); "tapped $label" }
            }
            "type_text" -> if (s.typeText(a.getString("text"))) "typed" else "no focused field"
            "swipe" -> { s.swipe(a.getString("direction")); "swiped" }
            "press" -> { when (a.getString("button")) {
                "back" -> s.back(); "home" -> s.home(); "recents" -> s.recents(); else -> s.notifications() }; "pressed" }
            "open_app" -> openApp(a.getString("name"))
            "finish" -> { log("✅ " + a.optString("summary")); "done" }
            else -> "unknown tool"
        }
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?: return "app not found"
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return "cannot launch"
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "opened ${match.loadLabel(pm)}"
    }
}
