package com.silverframes.deviceagent

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine

class MainActivity : AppCompatActivity() {
    private var agent: Agent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("agent", MODE_PRIVATE)

        val key = EditText(this).apply { hint = "Anthropic API key"; setText(prefs.getString("key", "")) }
        val goal = EditText(this).apply { hint = "What should I do on your phone?" }
        val logView = TextView(this)
        val a11y = Button(this).apply { text = "1. Enable accessibility service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val ask = Switch(this).apply { text = "Ask before risky actions (send, pay, delete)"; isChecked = false }
        val start = Button(this).apply { text = "2. Run task" }
        val stop = Button(this).apply { text = "Stop"; setOnClickListener { agent?.stopped = true } }

        start.setOnClickListener {
            prefs.edit().putString("key", key.text.toString()).apply()
            agent = Agent(this, key.text.toString(),
                log = { m -> runOnUiThread { logView.append(m + "\n\n") } },
                confirm = { q -> ask(q) })
            agent!!.askBeforeRisky = ask.isChecked
            lifecycleScope.launch { agent!!.run(goal.text.toString()) }
        }

        setContentView(ScrollView(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40)
                listOf(key, a11y, goal, ask, start, stop, logView).forEach { addView(it) }
            })
        })
    }

    private suspend fun ask(question: String): Boolean = suspendCancellableCoroutine { c ->
        runOnUiThread {
            AlertDialog.Builder(this).setMessage(question).setCancelable(false)
                .setPositiveButton("Allow") { _, _ -> c.resume(true) {} }
                .setNegativeButton("Deny") { _, _ -> c.resume(false) {} }.show()
        }
    }
}
