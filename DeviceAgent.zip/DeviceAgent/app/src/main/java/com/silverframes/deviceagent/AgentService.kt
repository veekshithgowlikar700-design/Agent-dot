package com.silverframes.deviceagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

/** The agent's "hands and eyes": reads the screen, taps, types, swipes. */
class AgentService : AccessibilityService() {

    companion object { @Volatile var instance: AgentService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    /** Compact JSON of everything visible: text + tap coordinates. */
    fun screenToJson(): String {
        val root = rootInActiveWindow ?: return "[]"
        val out = JSONArray()
        fun walk(n: AccessibilityNodeInfo) {
            val text = n.text?.toString() ?: n.contentDescription?.toString()
            if (text != null || n.isClickable || n.isEditable) {
                val r = Rect(); n.getBoundsInScreen(r)
                out.put(JSONObject()
                    .put("text", text ?: "")
                    .put("x", r.centerX()).put("y", r.centerY())
                    .put("clickable", n.isClickable)
                    .put("editable", n.isEditable))
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return out.toString()
    }

    fun tap(x: Int, y: Int) = gesture(Path().apply { moveTo(x.toFloat(), y.toFloat()) }, 50)

    fun swipe(direction: String) {
        val m = resources.displayMetrics
        val cx = m.widthPixels / 2f; val cy = m.heightPixels / 2f; val d = m.heightPixels / 4f
        val p = Path()
        when (direction) {
            "up" -> { p.moveTo(cx, cy + d); p.lineTo(cx, cy - d) }      // scroll down the page
            "down" -> { p.moveTo(cx, cy - d); p.lineTo(cx, cy + d) }
            "left" -> { p.moveTo(cx + d, cy); p.lineTo(cx - d, cy) }
            else -> { p.moveTo(cx - d, cy); p.lineTo(cx + d, cy) }
        }
        gesture(p, 300)
    }

    fun typeText(text: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    private fun gesture(path: Path, ms: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        dispatchGesture(g, null, null)
    }
}
