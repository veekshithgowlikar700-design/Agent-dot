# Device Agent (Android)

An AI agent that sees your screen and operates your phone (tap, type, scroll,
open apps) to complete tasks you describe in plain language.

## Setup
1. Android Studio -> New Project -> Empty Views Activity
   Package: com.silverframes.deviceagent, Language: Kotlin, Min SDK 26.
2. Replace AndroidManifest.xml and copy the 3 .kt files into
   app/src/main/java/com/silverframes/deviceagent/.
3. Add res/xml/accessibility_config.xml and res/values/strings.xml from this zip.
4. app/build.gradle(.kts) dependencies:
   implementation("com.squareup.okhttp3:okhttp:4.12.0")
   implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
   implementation("androidx.appcompat:appcompat:1.7.0")
   implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
5. Build -> install APK -> open app -> enable the accessibility service
   (Android may require: App info -> ⋮ -> Allow restricted settings).
6. Paste your Anthropic API key, type a goal, tap Run.

## How it works
Screen -> JSON -> Claude -> one tool call (tap/type/swipe/open_app/press)
-> AgentService executes -> new screen -> repeat (max 30 steps).

## Safety built in
- Runs fully on its own by default. Optional switch: ask YOU before send/pay/buy/delete taps.
- System prompt forbids entering passwords/payment details.
- Stop button; 30-step cap.

## Next upgrades
- Move API key to EncryptedSharedPreferences, or proxy via your own server.
- Foreground service + floating overlay stop button.
- Screenshots for apps that hide text from accessibility (games, some banking apps).
- Voice input, notification listener, contacts/SMS/calendar tools.
